package com.example.bulletit;

        import androidx.appcompat.app.AppCompatActivity;

        import android.app.Activity;
        import android.content.Context;
        import android.os.Bundle;
        import android.text.InputType;
        import android.util.Log;
        import android.view.Gravity;
        import android.view.KeyEvent;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.inputmethod.EditorInfo;
        import android.view.inputmethod.InputMethodManager;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.LinearLayout;
        import android.widget.PopupWindow;
        import android.widget.TextView;

        import org.w3c.dom.Text;

        import java.text.DateFormat;
        import java.text.SimpleDateFormat;
        import java.util.Calendar;
        import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private android.widget.Button dateBtn;
    private Object MainActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dateBtn = findViewById(R.id.DateButton);
        Date currentTime = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("E MMM dd");
        String dateString = dateFormat.format(currentTime);

        final TextView todoView = (TextView) findViewById(R.id.todo);
        System.out.println(this.toString());
//        final TextView todoItem = new TextView(this.);

        todoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                System.out.println("todo click");
                final EditText todoItem = new EditText(MainActivity.this);
                todoItem.setText("todo item");
                final LinearLayout todoBox = findViewById(R.id.todoBox);
                todoBox.addView(todoItem);
                todoItem.setInputType(InputType.TYPE_CLASS_TEXT);
                todoItem.setImeOptions(EditorInfo.IME_ACTION_DONE);
                todoItem.setFocusable(true);
//                todoItem.setEnabled(true);
//                todoItem.setClickable(true);
                todoItem.setFocusableInTouchMode(true);
                todoItem.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                        if (actionId == EditorInfo.IME_ACTION_DONE) {
                            todoItem.clearFocus();
                            todoItem.setVisibility(View.GONE);
                            closeKeyboard();
                            return true;
                        }
                        return false;
                    }
                });
            }
        });

//        final EditText zoop = (EditText) findViewById(R.id.zoop);
//        zoop.setun


        dateBtn.setText(dateString);

        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToMonthlyViewActivity();
            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void moveToMonthlyViewActivity(){
        android.content.Intent intent = new android.content.Intent(MainActivity.this, MonthlyViewActivity.class);
        startActivity(intent);
    }
}